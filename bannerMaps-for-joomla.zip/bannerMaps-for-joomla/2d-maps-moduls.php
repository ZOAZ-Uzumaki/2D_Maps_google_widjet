<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>ModuleForDivFormat</title>
</head>
<body>

<!-- ----------HTML------------- -->

<div class="TryDmoduleObjectFormat">

	

	<div class="TryDml_background-full"> <iframe class="thr-maps-sizer" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d612.5599432936585!2d30.528689802137585!3d50.44987235572106!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40d4ce523b68d127%3A0x7bbf1b03f2817ad6!2z0JzRg9C30LXQudC90YvQuSDQv9C10YAuLCA0LCDQmtC40LXQsiwg0KPQutGA0LDQuNC90LAsIDAyMDAw!5e0!3m2!1sru!2spl!4v1674849200979!5m2!1sru!2spl" width="800" height="350" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>


<hr>
		<img class="tdm_all_opened" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAADOElEQVR4nO2WS08aURxH2Tdpamx4JDqIIOjwUD9JXUzY8D267K4ktY0prc+pm6Kioigi1NbaZXcujFFrsIIV5gnYD3Bv828uFqLWgSuCtcmc5BdJSJhzwsxFg0FHR0dHR0dHR+daLFPZITOfzZOR14Y7whoWhqwzQt46k893hIXGrmvmTzgLn0UW/gTKm8piC38SMLQY20yOs87mUdesANYZAazhHGbCp4Hbyd9RhC0icl1zAuqaE6C8RiI05VscYYuInC0iINu8CLaICA1FkPu8pnx1WWTif/ibJW9flPzd8yLqXhChmwRoR6DO98ITzQ8qP6x15ZsbYV+U/PZFEdkXJbAvSFAvggnnTrUDprI5+oDy7YRMfKbhCPuS5HdEJeSISkBGE8GEhdMm3EJl+coainAS+SUJ9SzJQEYT8ed00r6FqB7iy/JgJpvM3OjBdsUUrmdZRs6YDD3L5wF1I+YEzMwJTTiJrspXNnGMLRPHdS/giiucc0VGrhUFnDEyioiIgG0LlPI1I7TkJzPnmzjGxhoRbFzhXKsK6l1VwEW2QhExL95c/tqIevKTGTCNfwfTaBobQ+m/LsiuK1xvXEF9cRV6yagixMblL0VMZRGV/NgRmN6mwfj6G24f2QtclO9bUxGbUKFvTQW6CAk7oreUr0ZMHJcjqORDh/B4ZA/aX+zgR8HtAJFnEypi1wvAJshoIiTsiMrN/bUnEeZKRD354R1oC26DKbT7y50qYHeyAG4SQBUhY1esyfKXIiYziEbeHNoFT6oAnlSxPLoIuXXyVyNqyr/ZBe+HIng3iuW/dBFK6+WrEaNpzjR2hLTkfRtF8H0sgW+jRBmhYDZeuBv5akQozRlDh+iivIXIfypBPxkJoIpQMbt+x/IVHo/s+tuHd1BFvn+zBAObZ9BPRhHBJlTUt6Y27d/yhmh7vu1/+Owr8iZVGPx8BgNkFBHuZAF5kv9YvsKDp1/8vqQCg1s/qSI8KRU8ydL9kK9g5fdeDm6d1Y0g30Dnu4Nhw32EmT58VSuCnE4d/MG44T7DaESQ04m57/JaEeR0+m/kKzDT+0FvSsaepIwZfj9YfUNHR0dHR0fHUOU3xOaHEiPfgNAAAAAASUVORK5CYII=">


		


		<div class="TryDml_backfuter">  

			
		<ul>

			<input class="trm_inputbufer" type="text" value="4 Музейний перевулок, Київ, Україна 02000, Кардінати[50.44981870032401, 30.52987314252954]" id="myInput">


			<li><button id="copy" onclick="myFunction()" class="td_button_1" title="Copy the adress!"><a href="#copy"><img class="td_img1" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAACXBIWXMAAAsTAAALEwEAmpwYAAAHuklEQVR4nO2beVAU2R3HqUpl/01V/kz+2qpUpSr/bv5IUrVzQM8BqCiCK4jrigo6PQMDjILsIAyHHJ4seIBGMGbjEQ/wWNfdVW7kEJVlueVWueaAmekBheGbek1g1ZEVGHpoQl7Vp6qne4qp36d/7/3ee924uf2/Od+EFP1nsUyZ47U+6qG3r6aGa8jvSNaEl4qlygIhpYhxdw/9/TIGr9glkiqnwiKP20/kXMPpMzdcwr7YE5CujbBv+CzWKJLS4wKKDnd58GLZ7j+KpLT96vUHmJiYdCm371bCf4sWVsaGwlul8PBUTQhlyjSXChBK6ISALxLGGNsYXE3h7TJWwMzn8sp6eHiGTYqlqhSXCRBIFOfik85O8UEAoaziKdzlYZNimVLnGgEUnZeUmg++CHhTgrtcGe8SAYmpebzJgBlKy59ALFfZ3eXhBzgXkJSaZ+ebAEJx2WOIZUq7u1z1JacCEnkqgPDd/RpWglim2s+dgIP8FcBK+KEGIik9JZIp93EiQHfw3CSfBRC+/b6azQShVKmcMxihBy3yXq/pILM6oYQGHyAB/vPSPacFEG5/U0EywS6k6O0OwX8qUX5MeYVNHM28iKf1bWhu6ZqTxqZO1NQ2sxSXPGGZ+bzUXL1eBNmaCHam5xDQ3Qps3By7oKy5WlAEsVQ5KfCg//qWAO8Ne6MDt+lev3r1GnzjxOlrUO/NdAimqrYR7nIVBoeNC5KQknYenj6RPf7+/r/6uS9L6NRwzbFxhhkD37h4+Xts25nsEIjZwmBTUBxitCfR1dM/bwEDgwZIvMPtIg9644oWMJMFgdt0ixtjKDpzxQjYsl2Hru6XMI2Y3xIwarai7Vkfyit/ROGtMhTMk92qw3ZSwdxWkoDW9l50dL1wyAKLlcGw3oT+AT36B+eHVndmZQpobe9lA3Z2DpF4MG9qVQtISsvHvAWYRiwwGEc5x2Qy80+AxcKguPQxikrqXILBMMIvAQxPM8DKjKG3b5Ct/3NBrpPvOS2A4eEYYDSZUVX9EyqrGuaEXCff+58UwCx1FxBKFGlhUcdfrWoB6jkygAyEo6NWzjGbrfwTYHF5FRjllwCGGcOIi6qA0biMVUD4CwJcyeCQEZ1kvu/qKiDkgYCn9e3wDdRCFXWcX12AcQE3bpaA8lJDviEae9RHV4+AkRELDh+/BLFMBc2RO4hIL2QFDJNtLj4IsFht+KmxA/U/ti+aFy+H3xt8b+8AdirS4e23H4evNyG/1obdyQUIUR5Ca1svPwRYrWNoae1mJSyW/n69Q/APqxuwxncfAkKOILd4EOdqbDhaYkVoSiE8vMLhu1kLvy0HWHw27YfcRwPfAC3LzHnC5ztToDeY2KBGRi14XN+GuictLOSYnONVF7Babbjw9bfkwSVo3SWcr7Egt4rB4WIrS8qdAcSeLMaXp4o+iObIbXZvr7N7epeIZEbbs172hhHI8VzZ4iiAUqSHczwV1utHEBufAw8vNQ7kluDCIxtOVvwc/Axnqhj8vdr2QTLvPWcFNDV3zHmn598FKEW6WpPJmYC29j4EBSfBJyAemXc6cf6RDV+VOQa/EBILe1kBldUN0OtN/BXwoPgR5D5R2BqWjbPlBuTV2HCsdPGBu1SA1TqG5pb5DYJ9fYPvre8iqRKK+H/h9P2XOPPQiiNOBu5yAY1NnfMqdz09Aw4Camqb4LVeg827DiH5ShMSC/uQcX+UEwHOVQGKuy7Q1d2P4N1pkG+IQeSph9Dd6EHaPcOSC3C6Cqg5HATJfp8uJQ9ieRhCk28i4Vo3W/IOFVn43QWYJebKtQfsE93P6BOIu/wMSTef49CDt7tEYkEvK+hDxOTXrzwBDBkXHjVhnV8MfLYmY/8/GtgukfGDiQ0+7lILAsNzERD2YTbtyXaNAINxlF2cLBayq/Tu33z+fAghdAZkPnuhziqD7no3Uu8OIySpAGs3RiMuIXeW4JAUePpEQROdxaIl53XTkHcUm1q6uRNgWYItsba2nvdmgtnMIDP7CrsS3K69jPirXQiOu4IdinR2MdTR+YLldO4NBHwej4qqBpZnHX3sQ9I30RtGYDSNsq/GFZXWsZBjcm5eAgQUnTFXBji7KUrm/7/UJe7crQDlrYZf6DEEReUheM+0gJnrX1/8DluDE2dXg+Tl6Lnu7MCQAf0D05DjeWeAgAjY+9WybYuTuYZfYBxEUpVTAhbdBQTLLIAwNGREZHQWomKyV6cA5o1doq6ul6tXAPPfnSheCLBYGJSWPXHJQxFSbYxGxwcjy54Bw8Mm9PcbOIe8vva+3+dCQIz21ISQUuTwtgu8KyBou2522W0wTtf8xTI4ZMC6jfve/icrAc8FBGyLR2n5U5aWtp7ZbFgoZNaoTciZojzD9BQV8psVISDr5L8h8VZPfbEreZywi04bWww79qSOydeqJ9xlSrOI2iOcDZ7vAs6eu0WW0Xqyc+0MAopOEkgVwX+RRvzW7d0mkNCpysij4654D2Ch5F/4BhLviEY3LptQrgySro14XVvXzM7C+EJzaw9C6YwJsUx1gVMBn3wS8mvKM7zOc13Ua7Um066JycJyExWThc1b48bdZSqLUKr4gxvX7U/+8R99KlHuEFKKbFIj+YCAUsT+jaJ/x3nwbqu4/QfO90gUNquSxwAAAABJRU5ErkJggg=="></a></button></li>

			<li>     </li>

			<li><button class="td_button_1" title="Link to google maps!"><a  target="_blank" href="https://www.google.com/maps/place/Музейный+пер.,+4,+Киев,+Украина,+02000/@50.4498724,30.5286898,19z/data=!4m5!3m4!1s0x40d4ce523b68d127:0x7bbf1b03f2817ad6!8m2!3d50.4499946!4d30.5296206"><img class="td_img1" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAACXBIWXMAAAsTAAALEwEAmpwYAAADyklEQVR4nO1bS08UQRAeuan/w9/gfWYPTI+a2DPxAh7Uk3qQh2D0MBtPGlQQnwENElxgRfGBegJXdyExUaIhgNEomAAmGEQvCiywZWqX2Zlh2WUe+yBNf8mXbDpT1VvVVd01Pd2CsA6BQMVuUaYHREWrlgitZ4GiTKskou1XFGWXkAM7RFk7LRH6RyIqMElZ/S0RtQZttVmu63qZSNTOkv/BopGGbE4QkyNvPnD42AlovHYbWtvuM0G0BW2y2ogpLhg5bw37y823IB6PA2tAmy413bSlg4JzAk4O5sifZNJ4A2hb5VEzEsRyqgiSTGuNhqbrLemHE4kE9L96kyT+dtO2lYHpYEsDkdCg0dAeCqcfRIOM9v5I1FXbVgbamHYAoUHuADFLBCRDOxKFgUjMHu4O2piIAFbBHRDKEQF1585Dd89jZhh++BSmpn84jwCJQWIFmNMBkqxVbmsH6LpeFpBpRanr9UKwo6sHpmc2SQEDsE3AHRDiEQD2VaD80B5RphP4lrQ+X1hE5ipA6FmjofNBL7AOXgmG+LsAZK0E2/nLUBhYB0+BEE8B4HMA4ZMg8FWA8GUQPNcBY78A2sYB9LcANTGAqqg3oizqQF2oMxeeTQDUxrzL52UZXFgGaBn1bvBmbB1N9bERzgz5k/ftgPgqQNOHwhlvEPtYXs3sv2+DCHAj79sBfRP2jrq/APz8B7Dq41sIyqKO3q8A1RbdLyYLJ+/JAYsrAHWDZgcDU5B3oE5Df/1gqs9CyHtywMicqbxhGMDtoOPz72ZTTOQYzYvDZj+jc+76cCrvyQERi3effAPXQMMNefydDajbeO71tPt+nMiXxAERh/JWR73P4aiiO2DEZwo4lcd2NBzpJc0KlgKLK6mJxVAem3H35/zKO0F0xjIJDgEs5XMSRDyftC+DXZ8BZl0sg37lNwLKzv4FeLRuGXz5PbuMZwcsuyiEsGDBusGrvB9e/VigQgiBZeYdh6Uwlq5+5L3w7hjAwkoRdoTG5wHujQMEs7wMYQRgyHuVd0qURR2o69O8o7/O9wTb+Z5gmO8JSnxPUOV7ghLfE1T5t0H+cZTwr8NB/nlc5OcD6PY+ICERtcZowOskrONKs+XKjEyrhIBycJ/1XC3Ll6aWluJQceS4eZZY1oiAV8fWblQmG/FqGYtOQOMbGm9Yw39+r6btTJ4TtqYBEg9NYjqU+rx/vohhbxv5FE+lD0rjNVK8Tlrqo+3FokjUjoz7wwJensYb45Z0YI0Y9msjn2G8YADnBJwYcYYUiXqBCaIt5VRJ57wF/wEK35RLLfLocQAAAABJRU5ErkJggg=="></a></button></li>
		</ul>


	  </div>

	  


	  
	</div>



<!-- JavaScript -->

<script type="text/javascript" >

function myFunction() {
  // Get the text field
  var copyText = document.getElementById("myInput");

  // Select the text field
  copyText.select();
  copyText.setSelectionRange(0, 99999); // For mobile devices

   // Copy the text inside the text field
  navigator.clipboard.writeText(copyText.value);

  // Alert the copied text
  alert("Copied the adress: " + copyText.value);
}

</script>


<!-- php -->

<?php 

	// 1

?>

<!-- Можливо потім зроблю 3д мапу тут -->


<!-- Them css -->

	<div id="TryDml_Them">
		
		<style type="text/css">
@media screen and (max-width: 1920px){

			.TryDmoduleObjectFormat{
				padding: 30px;
			}


	/*Colors*/
				.TryDml_background-full{
					background-color: #3DB5DF;

	/*other*/
					text-align: center;
					border-radius: 10px;
					padding: 10px;



 	/*sizer*/

                    margin-left: 470px;
                    margin-right: 470px;
				}


				.td_img1{
					width: 32px;
					padding: 5px;

				}


				.td_button_1{
					background-color: #fff;
					border-radius: 50%;
				    border: 0px solid #000;
				    margin: 5px;
				    box-shadow: 0px 0px 5px #fff;
				    transition: 0.1s;
				    margin-right: 30px;
				}

				.td_button_1:hover{
					transition: 0.2s;
					box-shadow: 0px 0px 15px #fff;
				}

				.td_button_1:active{
					transition: 0.1s;
					box-shadow: 0px 0px 15px #7CCFFF;
					background-color: #7CCFFF;
					margin-top: -10px;
					padding: 7px;

				}


				.TryDml_backfuter{
					background-color: #3DB5DF;
					opacity: 0%;
					margin-top: -50px;
					transition: 2s;
					padding: 5px;
					height: 100%;
					border-radius: 5px;
/*					transition-delay: 0.0s ease out;*/
					pointer-events:visible ;



				}

				.TryDml_backfuter:hover{
					transition: 0.7s;

					background-color: #5CBDDF;
					opacity: 100%;
					margin-top: 1px;
					margin-bottom: 0px;
					padding: 10px;


				}

				ul{
					text-decoration: none;
					display: inline;
				}

				li{
					text-decoration: none;
					display: inline;
				}

				table{
					text-decoration: none;
					display: inline;
				}

				.tdm_all_opened{
					transform: rotate(0deg);
/*					transition: 1s;*/
					margin-top: -10px;
				}

/*				.tdm_all_opened:hover{
					transition: 0.5s;
					transform: rotate(180deg);
					margin-top: 0px;
				}*/

				.trm_inputbufer{
					display: none;
				}


/*				Адаптація*/
/*Стандарт 1920 на 1080*/
/*Компютери*/ 


}

@media screen and (max-width: 1600px) {

	.TryDml_background-full{
			margin-right: 230px;
	}

	.thr-maps-sizer{
		height: 300px;
		width: 770px;

	}

}	

@media screen and (max-width: 1440px) {

	.TryDml_background-full{
			margin-right: 250px;
	}

	.thr-maps-sizer{
		height: 300px;
		width: 570px;

	}

}



@media screen and (max-width: 1366px) {

	.TryDml_background-full{
			margin-right: 230px;
	}

	.thr-maps-sizer{
		height: 300px;
		width: 570px;

	}

}	

/*Телефон*/

@media screen and (max-width: 1280px) {

	.TryDml_background-full{
			margin-right: 300px;
			margin-left: 300px;
	}

	.thr-maps-sizer{
		height: 250px;
		width: 550px;

	}

}	
@media screen and (max-width: 820px) {

	.TryDml_background-full{
			margin-right: 180px;
			margin-left: 180px;
	}

	.thr-maps-sizer{
		height: 250px;
		width: 350px;

	}

}	

@media screen and (max-width: 720px) {

	.TryDml_background-full{
			margin-right: 100px;
			margin-left: 100px;
	}

	.thr-maps-sizer{
		height: 250px;
		width: 400px;

	}

}	

@media screen and (max-width: 414px) {

	.TryDml_background-full{
			margin-right: 10px;
			margin-left: 10px;
	}

	.thr-maps-sizer{
		height: 250px;
		width: 280px;

	}

}	

@media screen and (max-width: 375px) {

	.TryDml_background-full{
			margin-right: 10px;
			margin-left: 10px;
	}

	.thr-maps-sizer{
		height: 240px;
		width: 240px;

	}

}	

@media screen and (max-width: 360px) {

	.TryDml_background-full{
			margin-right: 10px;
			margin-left: 10px;
	}

	.thr-maps-sizer{
		height: 250px;
		width: 240px;

	}

}	

@media screen and (max-width: 280px) {

	.TryDml_background-full{
			margin-right: 10px;
			margin-left: 10px;
	}

	.thr-maps-sizer{
		height: 250px;
		width: 140px;

	}

}	






		</style>
	</div>


</div>


<!-- ----------------------- -->

</body>
</html>